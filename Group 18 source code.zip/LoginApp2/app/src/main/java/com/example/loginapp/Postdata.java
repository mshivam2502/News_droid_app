package com.example.loginapp;

public class Postdata {

    private String head,type,desc,username,date;

    public Postdata() {
    }

    public Postdata(String head, String type, String desc, String username, String date) {
        this.head = head;
        this.type = type;
        this.desc = desc;
        this.username = username;
        this.date = date;
    }


    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
