package com.example.loginapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class NewRVAdapter extends RecyclerView.Adapter<NewRVAdapter.ViewHolder> {
//2ca3d8d845024bca9d00c98cd1f8bc6b
//https://newsapi.org/v2/everything?q=panvel&language=en&sortBy=publishedAt&apiKey=2ca3d8d845024bca9d00c98cd1f8bc6b
    private ArrayList<Articles> articlesArrayList;
    private Context context;

    public NewRVAdapter() {
    }

    public NewRVAdapter(ArrayList<Articles> articlesArrayList, Context context) {
        this.articlesArrayList = articlesArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_newslist,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Articles articles = articlesArrayList.get(position);
//        holder.newsimage.setImageResource(R.drawable.defaultimg);
        Picasso.get().load(articles.getUrlToImage()).into(holder.newsimage);
        holder.description.setText(articles.getDescription());
        holder.title.setText(articles.getTitle());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context,NewsDetail.class);
                i.putExtra("head",articles.getTitle());
                i.putExtra("description",articles.getDescription());
                i.putExtra("url",articles.getUrl());
                i.putExtra("urlToImage",articles.getUrlToImage());
                i.putExtra("content",articles.getContent());
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return articlesArrayList.size();
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title,description;
        ImageView newsimage;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.NewsHeading);
            description = itemView.findViewById(R.id.NewsDescription);
            newsimage = itemView.findViewById(R.id.IVNews);
        }
    }
}
