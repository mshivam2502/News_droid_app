package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class NewsDetail extends AppCompatActivity {

    TextView titletv,destv,contenttv;
    Button link;
    ImageView imageView;

    String title, description,url,urlToImage,content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_detail);
        title = getIntent().getStringExtra("head");
        description = getIntent().getStringExtra("description");
        content = getIntent().getStringExtra("content");
        url = getIntent().getStringExtra("url");
        urlToImage = getIntent().getStringExtra("urlToImage");

        titletv = findViewById(R.id.DTitle);
        destv = findViewById(R.id.Ddesciprtion);
        contenttv = findViewById(R.id.contenttv);
        link = findViewById(R.id.linkbtn);
        imageView = findViewById(R.id.DNewsIV);

        titletv.setText(title);
        destv.setText(description);
        contenttv.setText(content);
        Picasso.get().load(urlToImage).into(imageView);

        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

    }
}