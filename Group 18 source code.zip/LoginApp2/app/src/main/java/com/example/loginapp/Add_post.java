package com.example.loginapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.Timestamp;
import java.util.Date;

public class Add_post extends AppCompatActivity {

    FirebaseDatabase db;
    DatabaseReference dbref;
    private Button post;
    private EditText heading,ETtype,description;
    private String i,head,type,desc,date,uid,username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);

        db = FirebaseDatabase.getInstance();
        dbref = db.getReference();

        heading = findViewById(R.id.post_head);
        ETtype = findViewById(R.id.post_type);
        description = findViewById(R.id.post_description);
        post = findViewById(R.id.post_btn);


        username = getIntent().getStringExtra("username");
        i = getIntent().getStringExtra("count");

        Date d = new Date();
        java.sql.Timestamp timestamp = new java.sql.Timestamp(d.getTime());

        date = timestamp.toString();

        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                head = heading.getText().toString();
                type = ETtype.getText().toString();
                desc = description.getText().toString();

        dbref.child("UserId's").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {

                if(task.isSuccessful()){

                    if(task.getResult().exists()){
                        DataSnapshot dataSnapshot = task.getResult();
                        uid = String.valueOf(dataSnapshot.child(username).getValue());
                        Toast.makeText(Add_post.this, "User id: "+uid, Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(Add_post.this, "Data Doesn't exist", Toast.LENGTH_SHORT).show();
                    }

                }
                else{
                    Toast.makeText(Add_post.this, "Couldn't Retrieve data", Toast.LENGTH_SHORT).show();
                }


            }
        });

        addData();

            }
        });


    }

    public void addData() {
        dbref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Postdata p = new Postdata(head, type, desc, username,date);
                dbref.child("Articles").child(uid).child(i).setValue(p);
                Toast.makeText(Add_post.this, "Data added", Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Add_post.this, "Unable to add data", Toast.LENGTH_SHORT).show();
            }
        });
    }

}