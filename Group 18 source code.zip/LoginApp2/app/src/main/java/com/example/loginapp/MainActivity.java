package com.example.loginapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private EditText user;
    private EditText pass;
    private Button login;
    private Button register;
    FirebaseDatabase db;
    DatabaseReference dbref;
    FirebaseAuth mAuth;
    int i=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Firebase controls
        db = FirebaseDatabase.getInstance();
        dbref = db.getReference("UserData");
        mAuth = FirebaseAuth.getInstance();

        //other initializations
         user = findViewById(R.id.editTextLogin);
        login = findViewById(R.id.LoginButton);
         pass = findViewById(R.id.editTextPassword);
         register = findViewById(R.id.RegisterButton);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent afterlogin = new Intent(MainActivity.this, AfterLogin.class);
                afterlogin.putExtra("username",user.getText().toString());
                afterlogin.putExtra("count",i);


                if(!TextUtils.isEmpty(user.getText().toString())&&!TextUtils.isEmpty(pass.getText().toString())) {

                    // /*#######################################################################
                    String us = user.getText().toString() + "@gmail.com";
                    String pw = pass.getText().toString();

                    mAuth.signInWithEmailAndPassword(us, pw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "Welcome :)", Toast.LENGTH_SHORT).show();
                                startActivity(afterlogin);
                                user.setText("");
                                pass.setText("");
                            } else {
                                user.setError("Invalid username or password");
                                pass.setError("Invalid username or password");
                                user.setText("");
                                pass.setText("");
                            }
                        }
                    });
                    //#######################################################################*/
                }
                else{
                    user.setError("Invalid username or password");
                    pass.setError("Invalid username or password");
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Registration Form", Toast.LENGTH_SHORT).show();
                Intent afterReg = new Intent(MainActivity.this, RegisterPage.class);
                startActivity(afterReg);
            }
        });
    }
}