package com.example.loginapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class RegisterPage extends AppCompatActivity {

    private Button back, otpbtn, verifybtn;
    private FirebaseAuth mAuth;
    FirebaseDatabase db;
    DatabaseReference dbref;
    private EditText phone, otp, ruser, rpass;
    private String verifyid;
    FirebaseUser fuser;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        back = findViewById(R.id.back_button);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        // Firebase OTP linking
        //firebase instance
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        dbref = db.getReference();
        fuser = mAuth.getCurrentUser();
        //name = fuser.getUid();

        // other initialization
        otpbtn = findViewById(R.id.OTPBtn);
        verifybtn = findViewById(R.id.VerifyBtn);
        phone = findViewById(R.id.Phonefield);
        otp = findViewById(R.id.OTPfield);
        ruser = findViewById(R.id.Rusername);
        rpass = findViewById(R.id.Rpassword);

        otpbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //checking if fields are valid or not
                if (TextUtils.isEmpty(phone.getText().toString())) {
                    //if phone field is empty i.e. user hasn't entered phone then give prompt
                    Toast.makeText(RegisterPage.this, "Enter valid Phone Number", Toast.LENGTH_SHORT).show();
                } else {
                    //sending code to user
                    String num = "+91" + phone.getText().toString();
                    sendVerificationCode(num);
                }
            }
        });

        verifybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(otp.getText().toString())) {
                    otp.setError("Enter valid OTP");
                } else if (TextUtils.isEmpty(phone.getText().toString())) {
                    phone.setError("Enter valid Phone Number");
                } else if (TextUtils.isEmpty(ruser.getText().toString())) {
                    ruser.setError("Enter valid username");
                } else if (TextUtils.isEmpty(rpass.getText().toString())) {
                    rpass.setError("Enter a valid password");
                } else if (rpass.getText().toString().length() < 8) {
                    rpass.setError("Password should be 8 characters long");
                } else {
                    verifyCode(otp.getText().toString());

                }

            }

        });

    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        //checking of entered code/OTP
        mAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    //enters if OTP is right
                    Toast.makeText(RegisterPage.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                    dbref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Users user = new Users(ruser.getText().toString(), rpass.getText().toString(), phone.getText().toString());
                            uid obj = new uid();obj.setId();
                            name = obj.getId();
                            dbref.child("UserId's").child(ruser.getText().toString()).setValue(name);

                            dbref.child(name).setValue(user);
                            finish();
                            Toast.makeText(RegisterPage.this, "Data added successfully", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(RegisterPage.this, "Unable to add data", Toast.LENGTH_SHORT).show();
                        }
                    });
                    String username = ruser.getText().toString() + "@gmail.com";
                    mAuth.createUserWithEmailAndPassword(username,rpass.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(RegisterPage.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(RegisterPage.this, "User not registered", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } else {
                    Toast.makeText(RegisterPage.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void sendVerificationCode(String num) {
        //code used to send OTP to phone
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(mAuth)
                .setPhoneNumber(num) //phone no. to verify
                .setTimeout(60L, TimeUnit.SECONDS) //timeout and unit
                .setActivity(this) //Activity for call back binding
                .setCallbacks(mCallBack) // OnVerificationStateChangedCallbacks
                .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks

            //initializing callbacks
            mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override

        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            // when we receive the OTP it contains a unique id which we are storing in our string which we have already created.
            verifyid = s;
        }


        public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
            final String code = phoneAuthCredential.getSmsCode();
            if (code != null) {
                otp.setText(code);
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {
            Toast.makeText(RegisterPage.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    };

    private void verifyCode(String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verifyid, code);
        signInWithCredential(credential);
    }

}