package com.example.loginapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface RetroFitAPI {
    @GET
    Call<News_modal> getAllNews(@Url String url);
}
