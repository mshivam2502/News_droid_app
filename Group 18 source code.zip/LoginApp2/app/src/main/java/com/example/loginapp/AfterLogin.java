package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AfterLogin extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NewRVAdapter adapter;
    private DrawerLayout drawer;
    private ImageButton menu,search;
    private NavigationView nv;
    private Button postbtn;
    private ArrayList<Articles> articlesArrayList;
    private EditText cityet;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_login);

        String username = getIntent().getStringExtra("username");
        nv = findViewById(R.id.nav_bar);
        View v = nv.getHeaderView(0);
        MenuItem Item= nv.getCheckedItem();
        TextView userfield = v.findViewById(R.id.nav_user);

       postbtn = findViewById(R.id.add_post);
       i=getIntent().getIntExtra("count",0);


       cityet = findViewById(R.id.getCity);
       search = findViewById(R.id.searchbtn);
        userfield.setText(username);
        //News display on home page
        recyclerView = findViewById(R.id.newsList);
        articlesArrayList = new ArrayList<>();
        adapter = new NewRVAdapter(articlesArrayList,this);
        recyclerView.setAdapter(adapter);




        //nav bar controls
        drawer = findViewById(R.id.drawer);
        menu = findViewById(R.id.menubtn);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.open();
            }
        });

        postbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AfterLogin.this,Add_post.class);
                String count = "post"+String.valueOf(i);
                intent.putExtra("username",username);
                intent.putExtra("count",count);
                startActivity(intent);
                i++;
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(cityet.getText())){
                    getNews("panvel");
                }
                else{
                    getNews(cityet.getText().toString());
                }
            }
        });
        getNews("panvel");
        adapter.notifyDataSetChanged();

    }

public void getNews(String city){
        articlesArrayList.clear();
        String url = "https://newsapi.org/v2/everything?q="+city+"&language=en&sortBy=publishedAt&apiKey=2ca3d8d845024bca9d00c98cd1f8bc6b";
        String Base_url = "https://newsapi.org/";

        Retrofit retroFit = new Retrofit.Builder()
                .baseUrl(Base_url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetroFitAPI retroFitApi = retroFit.create(RetroFitAPI.class);

    Call<News_modal> call = retroFitApi.getAllNews(url);

    call.enqueue(new Callback<News_modal>() {
        @Override
        public void onResponse(Call<News_modal> call, Response<News_modal> response) {
            News_modal news_modal = response.body();
            ArrayList<Articles> articles = news_modal.getArticles();
            for(int j=0;j<articles.size();j++){
                articlesArrayList.add(new Articles(articles.get(j).getTitle(),articles.get(j).getDescription(),articles.get(j).getUrl(),
                        articles.get(j).getUrlToImage(),articles.get(j).getContent()));
            }

            adapter.notifyDataSetChanged();

        }

        @Override
        public void onFailure(Call<News_modal> call, Throwable t) {
            Toast.makeText(AfterLogin.this, "Fail to get news", Toast.LENGTH_SHORT).show();
        }
    });

}

   /* @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == 0) {
        return false;
        }
        switch (item.getItemId()){
            case R.id.useraccount:
                Intent i = new Intent(AfterLogin.this,Account_info.class);
                startActivity(i);
                drawer.close();
                break;

            case R.id.Home:

            case R.id.bookmarks:
                drawer.close();
                break;

            case R.id.logout:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }*/

    @Override
    public void onBackPressed() {

        if(drawer.isOpen()){
            drawer.close();
        }
        else{
            super.onBackPressed();
        }


    }
}